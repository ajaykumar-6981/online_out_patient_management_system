<?php

    //connectivity
  $con=mysqli_connect("localhost","root") or die("not connected");
  //select database
  mysqli_select_db($con,"out_patient_management");

if(isset($_POST['create']))
{
 $doctor_name=$_POST['doctor_name'];
 $email=$_POST['email'];
 $password=$_POST['password'];
 $dob=$_POST['dob'];
 $qualification=$_POST['qualification'];
 $year_of_experience=$_POST['year_of_experience'];
 $specialty=$_POST['specialty'];
 $availability_at_hospital=$_FILES['availability_at_hospital'];
 
 print_r($prescription);
 
 $sql="INSERT INTO doctor(doctor_name,email,password,dob,qualification,year_of_experience,specialty,availability_at_hospital)
      VALUES('$doctor_name','$email','$password','$dob','$qualification','$year_of_experience','$specialty','$availabilty_at_hospital')";

$qry=mysqli_query($con,$sql);

//if($qry)
//{
  ?>
         <script>                   // here script is out of php
                alert('Data Entered Successful');
        </script>

//  <?php
//}

}

?>


<html>
  <head>
    <title>Doctor Registration</title>
    <link rel='styleesheet' href='css/registration.css'>
    <link rel="stylesheet" href="Source/bootstrap-4.0.0-dist/css/bootstrap.min.css">
  </head>
  <body>
     <div class="container">
       <div class="card bg-light">
          <article class="card-body mx-auto" style="max-width:auto">
             <form class="c_registration.php" id='form' method="post">
        		<h2 class="card-title mt-3 text-center">Create Account</h2>

	                <div class="row">
	                   <div class="col-lg-12">
	                        <h4>Registration form</h4>
	                            <u>Fill up the forms with correct values</u>
		                          <hr class="mb-3">
                               
							   <div class='row'>
							        <div class='col-6'>
								        <label for id="name">Doctor Name</label>
		                                <input class="form-control" type="text" id="doctor_name"name="doctor_name" placeholder='doctor name...'required>
							        </div>
                                    <div class='col-6'>
								       <label for id="email">Email</label>
		                               <input class="form-control"type="text" id="email" name="email" placeholder='email...' required></br>
								    </div>
                                    
                               </div>
                               <div class='row'>
                                       <div class='col-6'>
                                            <label for id="password">Password</label>
                                            <input class="form-control"type="password" id="password" name="password" placeholder='password..' required></br>
                                       </div>
                                       <div class='col-6'>
								            <label for id="dob">DOB</label>
		                                    <input class="form-control"type="date" id="dob" name="dob" placeholder='dob...' required>
							           </div>
							
                                </div>
							   <div class='row'>
                                   <div class='col-6'>
								       <label for id="qualification">Qualification</label>
		                               <input class="form-control"type="text" id="qualification" name="qualification" placeholder='qualification..' required></br>
								   </div>
							      <div class='col-6'>
								       <label for id="year_of_experience">Year_of_Experience</label>
		                               <select class="form-control" name="year_of_experience">
                                          <option value="">Select</option>
                                          <option value="1">1</option>
                                          <option value="2">2</option>
                                          <option value="3">3</option>
                                          <option value="4">4</option>
                                          <option value="more">more than 5 year</option>
                                       </select>    
                                   </div>
								   
							   </div>
							   <div class='row'>
							        <div class='col-6'>
								       <label for id="specialty">Specialty</label><br>
                                       <input class="form-control" type="text" name="specialty">
								    </div>
							        <div class='col-6'>
								       <label for id="availability">availability_at_hospital</label>
                                       <select class="form-control" name="year_of_experience">
                                          <option value="">Select</option>
                                          <option value="yes">YES</option>
                                          <option value="no">NO</option>
							        </div>
							    </div>
                                <br>
                         															
		                     <button class="btn btn-primary btn-block" type="submit" name="create">Sign Up</button>

                         <p>Have an Account?<a href="p_login.php">Sign in</a></p>
		               </div>
	                </div>

       </form>
     </article>
    </div>
   </div>
  
</body>

</html>
