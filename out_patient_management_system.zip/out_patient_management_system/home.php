<?php
  $con=mysqli_connect("localhost","root");
 mysqli_select_db($con,"out_patient_management");

?>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet" href="./css/sidebar.css">
    <link rel="stylesheet" href="./css/admins.css">
    <link rel="stylesheet" href="./css/modal.css">
    <link rel="stylesheet" href="Source/bootstrap-4.0.0-dist/css/bootstrap.min.css">
</head>
<body>
  <div class="container-fluid">
  <div class="nav">
            <div class="logo">
              <h2><a class="navbar-brand" href="#">ONLINE OUT-PATIENT MANAGEMENT SYSTEM</a></h2>
            </div>
            <ul class="list">
               <li><a class="active" href="#">Home</a></li>
               <li><a href="contactus.php">Contact Us</a></li>
            </ul>
        </div>
        <div class="banner">
           <img src="./images/home_opd.jpg"/>
        </div>
   </div>
  
  <div class="section">
      <div class="row d-flex justify-content-around">
      <div class="col-lg-4,col-md-4,col-sm-6">
            <div class="card" style="border:5px solid cyan;margin:5px 0px">
                <div class="card-body" style="background-color: #ccc">
                  <h5>Patients Login</h5>
                   <h5 style="color:cyan;text-align:center;">
                       <a href="p_login.php">For login Click Here</a>
                   </h5>  
                </div>
            </div>
         </div> 
         <div class="col-lg-4,col-md-4,col-sm-6">
            <div class="card" style="border:5px solid dodgerblue;margin:5px 0px">
                <div class="card-body" style="background-color: #ccc">
                  <h5>Doctor Login</h5>
                   <h5 style="color:dodgerblue;text-align:center;">
                   <a href="d_login.php">For login Click Here</a>
                   </h5>  
                </div>
            </div>
         </div> 
         <div class="col-lg-4,col-md-4,col-sm-6">
            <div class="card" style="border:5px solid green;margin:5px 0px">
                <div class="card-body" style="background-color:#ccc">
                   <h5>Admin Login</h5>
                   <h5 style="color:green;text-align:center;">
                   <a href="a_login.php">For login Click Here</a>
                   </h5>  
                </div>
            </div>
         </div>
         
      </div>
      
  </div> 
  <script src="../JS/sidebar.js"></script>
  <script src="JS/admin.js"></script>
</body>
</html>