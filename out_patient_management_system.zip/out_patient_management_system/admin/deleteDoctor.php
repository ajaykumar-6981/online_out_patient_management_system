<?php

$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'out_patient_management');

$id=$_GET['id'];

$q="delete from doctor where doctor_id=$id";

mysqli_query($con,$q);
header('location:doctorDetail.php');
?>