<?php
 
//connectivity
  $con=mysqli_connect("localhost","root") or die("not connected");
  //select database
  mysqli_select_db($con,"out_patient_management");

if(isset($_POST['add']))
{
  $patient_name=$_POST['patient_name'];
  $email=$_POST['email'];
  $father_name=$_POST['father'];
  $dob=$_POST['dob'];
  $gender=$_POST['gender'];
  $address=$_POST['address'];

 $qry="INSERT INTO `patient`(`fname`,`email`, `father_name`, `dob`,`gender`,`address`) VALUES ('$patient_name','$email','$father_name','$dob','$gender','$address')";

$res=mysqli_query($con,$qry);

if($res)
{
  ?>
         <script>                   // here script is out of php
                alert('Data Entered Successful');
        </script>

  <?php
    header('location:patientDetail.php');
}
else{
  echo"Data not entered";
}

}

?>