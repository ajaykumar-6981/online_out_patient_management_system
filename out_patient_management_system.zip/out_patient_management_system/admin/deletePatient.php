<?php

$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'out_patient_management');

$id=$_GET['id'];

$q="delete from patient where patient_id=$id";

mysqli_query($con,$q);
header('location:patientDetail.php');
?>