<?php
session_start();
include('../connection.php');
$invoice = $_POST['invoice'];
$date = $_POST['date'];
$amount = $_POST['amount'];
$profit = $_POST['profit'];
$cname = $_POST['cname'];

if($amount=='cash') {
$type = $_POST['cash'];
$sql = "INSERT INTO sales (invoice_number,date,type,amount,profit,name) VALUES ('$invoice','$date','$type','$amount','$profit','$cname')";
$q = $db->prepare($sql);
$q->execute($con,$q);
header("location: preview.php?invoice=$invoice");
exit();
}
// query



?>