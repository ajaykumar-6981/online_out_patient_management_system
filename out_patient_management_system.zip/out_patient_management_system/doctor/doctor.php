<?php
 session_start();

 $con=mysqli_connect("localhost","root");
 mysqli_select_db($con,"out_patient_management");

 if(!isset($_SESSION['email'])){
     header('location:../d_login.php');
 }

?>
<html>
<head>
    <title>Deshboard|Doctor</title>
    <link rel="stylesheet" href="../css/sidebar.css">
    <link rel="stylesheet" href="../css/admins.css">
    <link rel="stylesheet" href="../css/modal.css">
    <link rel="stylesheet" href="../Source/bootstrap-4.0.0-dist/css/bootstrap.min.css">
</head>
<body>
  <div class="container-fluid">
  <div class="nav">
            <div class="logo">
              <h2><a class="navbar-brand" href="#">ONLINE OUT-PATIENT MANAGEMENT SYSTEM</a></h2>
            </div>
            <ul class="list">
               <li><a href="#">Doctor</a></li>
               <li><a href="medicineDetail.php">MEDICINE DETAILS</a></li>
               <li><a href="managePatient.php">PATIENT DETAILS</a></li>
               <li><a href="doctorProfile.php">PROFILE</a></li>
               <li><a href="../logout.php">Logout</a></li>
            </ul>
            <div id="tooggle">III</div>
        </div>
        
        <div class="banner">
           <img src="../images/doctor6.png"/>
        </div>
        
      <!---side bar---->
      <div class="side">
            <div class="head">
              <h3 id="demo">ONLINE OUT-PATIENT MANAGEMENT SYSTEM</h3>
              <span class="close-btn">X</span>
            </div> 
          <ul class="ul" id="list">
            <li><a href="#">DOCTOR</a></li>
            <li><a href="medicineDetail.php">MEDICINE DETAILS</a></li>
            <li><a href="manageSchedule.php">SCHEDULE DETAILS</a></li>
            <li><a href="managePatient.php">PATIENT DETAILS</a></li>
            <li><a href="doctorProfile.php">PROFILE</a></li>
          </ul> 
        </div>
        
  </div>
  <h5 style="text-align:center">WELCOME: Doctor <?php echo $_SESSION['doctor_name'];?></h5>
  <div class="section">
      <div class="row d-flex justify-content-around">
      <div class="col-lg-4,col-md-4,col-sm-6">
            <div class="card" style="border:5px solid cyan;margin:5px 0px">
                <div class="card-body" style="background-color: #ccc">
                  <h5>Total Out-Patient in Hospital:</h5>
                   <h5 style="color:cyan;text-align:center;">
                   <?php
                       $query="SELECT patient_id FROM patient ORDER BY patient_id";
                       $res=mysqli_query($con, $query);
                       
                       $row=mysqli_num_rows($res);
                       echo "$row";
                   ?>
                   </h5>  
                </div>
            </div>
         </div> 
         <div class="col-lg-4,col-md-4,col-sm-6">
            <div class="card" style="border:5px solid orange;margin:5px 0px">
                <div class="card-body" style="background-color:#ccc">
                   <h5>Total Appointments:</h5>
                   <h5 style="color:orange;text-align:center;">
                   <?php
                       $query="SELECT patient_id FROM patient ORDER BY patient_id";
                       $res=mysqli_query($con, $query);
                       
                       $row=mysqli_num_rows($res);
                       echo "$row";
                   ?>
                   </h5>  
                </div>
            </div>
         </div>
         
      <button onclick="document.getElementById('id01').style.display='block'" style="width:100%;margin:auto;">ADD PRESCRIPTION</button>
       </div>
  </div> 
   <!-----------------------ADD DOCTOR PRESCRIPTION MODAL--------------------------------->
  <!--Step 1:Adding HTML-->
	
<div id="id01" class="modal">
  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">×</span>
  <form class="modal-content animate" action="addDoctorPrescription.php" method="POST">
    <article class="card-body m-auto"> 
            <div class='row'>
               <div class='col-6'>
                  <label for id="doctor_name">Patient Name</label>
                  <input class="form-control" type="text" id="name" name="name_of_patient" placeholder='Patient Name...' required>
               </div>
               <div class='col-6'>
                  <label for id="dob">DOB</label>
                  <input class="form-control" type="date" id="dob" name="dob" placeholder='dob...'required></br>
               </div>
            </div>
            <div class='row'>
               <div class='col-6'>
                  <label for id="gender">GENDER</label>
                  <input class="form-control"type="text" id="gender" name="gender" placeholder='gender...' required>
               </div>
               <div class='col-6'>
                  <label for id="prescription">PRESCRIPTION</label>
                  <input class="form-control" type="text" id="prescription" name="prescription" placeholder='prescription...'required></br>
               </div>
            </div>      
            <div class='row'>
               <div class='col-6'>
                  <label for id="date">DATE</label>
                  <input class="form-control"type="date" id="date" name="date_of_prescription" placeholder='date...' required>
               </div>
               <div class='col-6'>
                  <label for id="date_of_consultation">DATE OF CONSULTATION</label>
                  <input class="form-control" type="date" id="date_of_consultation" name="next_date_of_consultation" placeholder='date_of_consultation...'required></br>
               </div>
            </div>  
            <div class='row'>
               <div class='col-6'>
                  <label for id="medical_test">MEDICAL TEST</label>
                  <select class="form-control"type="text" id="medical_test" name="medical_test">
                     <option value="#">Select</option>
                     <option value="x-ray">X-Ray</option>
                     <option value="mri">MRI</option>
                     <option value="ct scan">CT Scan</option>
                     <option value="ultrasound">Ultrasound</option>
                     <option value="no need">No Need of Medical test</option>
                  </select>
               </div>
               <div class='col-6'>
                  <label for id="sign_of_doctor">DOCTOR'S SIGN</label>
                  <input class="form-control"type="" id="sign_of_doctor" name="sign_of_doctor" placeholder='doctor sign...' required>
               </div>
            </div>   
            <br>     
            <div class="clearfix">
                <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
                <button type="submit" class="signupbtn" name="create">Add</button>
            </div>
      </article>
    </form>  
</div>

<!--close the modal by just clicking outside of the modal-->
<script>
  var modal = document.getElementById('id01');

  window.onclick = function(event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
  }
</script>
  <script src="../JS/sidebar.js"></script>
  <script src="JS/admin.js"></script>
</body>
</html>