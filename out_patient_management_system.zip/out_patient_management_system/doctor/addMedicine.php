<?php
  
//connectivity
  $con=mysqli_connect("localhost","root") or die("not connected");
  //select database
  mysqli_select_db($con,"out_patient_management");


if(isset($_POST['create']))
{
 $medicine_name=$_POST['medicine_name'];
 $price=$_POST['price'];
 $quantity=$_POST['quantity'];
 
 $sql="INSERT INTO medicine(medicine_name,pricequantity)
 VALUES('$medicine_name','$price','$quantity')";

$qry=mysqli_query($con,$sql);

if($qry)
{
  ?>
         <script>                   // here script is out of php
                alert('Data Entered Successful');
        </script>

  <?php
    header('location:medicineDetail.php');
}

}

?>