<?php
  
//connectivity
  $con=mysqli_connect("localhost","root") or die("not connected");
  //select database
  mysqli_select_db($con,"out_patient_management");


if(isset($_POST['create']))
{
 $name_of_patient=$_POST['name_of_patient'];
 $dob=$_POST['dob'];
 $gender=$_POST['gender'];
 $prescription=$_POST['prescription'];
 $date_of_prescription=$_POST['date_of_prescription'];
 $next_date_of_consultation=$_POST['next_date_of_consultation'];
 $medical_test=$_POST['medical_test'];
 $procedures=$_POST['procedures'];
 $sign_of_doctor=$_POST['sign_of_doctor'];
 
 echo $sql="INSERT INTO prescription(name_of_patient,dob,gender,prescription,date_of_prescription,next_date_of_consulation,medical_test,procedures,sign_of_doctor)
 VALUES('$name_of_patient','$dob','$gender','$prescription','$date_of_prescription','$next_date_of_consultation','$medical_test','$procedures','$sign_of_doctor')";

$qry=mysqli_query($con,$sql);

if($qry)
{
  ?>
         <script>                   // here script is out of php
                alert('Data Entered Successful');
        </script>

  <?php
    header('location:doctor.php');
}

}

?>