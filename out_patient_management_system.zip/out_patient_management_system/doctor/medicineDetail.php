<html>
<head>
    <title>medicine details| Doctor</title>
    <link rel="stylesheet" href="../css/admins.css">
    <link rel="stylesheet" href="../css/modal.css">
    <link rel="stylesheet" href="../Source/bootstrap-4.0.0-dist/css/bootstrap.min.css">
</head>
<body>
  <div class="container-fluid">
      <div class="nav">
         <div class="logo">
           <h2><a class="navbar-brand" href="#">ONLINE OUT-PATIENT MANAGEMENT SYSTEM</a></h2>
         </div>
         <ul class="list">
               <li><a href="doctor.php">DOCTOR</a></li>
               <li><a href="#" class='active'>MEDICINE DETAILS</a></li>
               <li><a href="managePatient.php">PATIENT DETAILS</a></li>
               <li><a href="#">Logout</a></li>
         </ul>
      </div>
      <div class="banner">
           <img src="../images/medicine.jpeg"/>
      </div>
      <div class="banntext"> 
         <button onclick="document.getElementById('id01').style.display='block'">ADD MEDICINES</button> 
      </div>   
   </div>
  <!--------------------------------------------
        //  list of medicine
   ------------------------------------------------->
   <div class="col-12">
     <div class="card">
        <table class="table table-hover table-bordered">
                <tr class="bg-dark text-white  text-center">
                    <th>Medicine Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Delete</th>
                    <th>Update</th>
                </tr>
        <?php
               session_start();

              if(!isset($_SESSION['doctor_name']))
               {
                  header('location:d_login.php');
               }
              // include 'connection.php';

              //connectivity
            $con=mysqli_connect("localhost","root") or die("not connected");
            //select database
            mysqli_select_db($con,"out_patient_management");

                $query="SELECT * FROM medicine";
                $q=mysqli_query($con,$query);
                
                 while($res=mysqli_fetch_array($q))
                {

        ?>
                <tr class="text-center">
                    <td><?php echo $res['medicine_name']; ?></td>
                    <td><?php echo $res['price']; ?></td>
                    <td><?php echo $res['quantity']; ?></td>
                    <td><button class="btn-danger btn"><a href="deleteMedicine.php?id=<?php echo $res['medicine_id']; ?>" class="text-white">Delete</a></button></td>
                    <td><button class="btn-primary btn"><a href="updationMedicine.php?id=<?php echo $res['medicine_id']; ?>" class="text-white">Update</a></button></td>
                </tr>

          <?php
        }
           ?>
          </table>
      </div>

  </div>
 <!-----------------------ADD MEDICINES MODAL--------------------------------->
  <!--Step 1:Adding HTML-->
	

<div id="id01" class="modal">
  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">×</span>
  <form class="modal-content animate" action="addMedicine.php" method="POST">
    <article class="card-body m-auto"> 
            <div class='row'>
               <div class='col-6'>
                  <label for id="medicine_name">Medicine Name</label>
                  <input class="form-control"type="text" id="medicine_name" name="medicine_name" placeholder='medicine_name...' required>
               </div>
               <div class='col-6'>
                  <label for id="price">Price</label>
                  <input class="form-control" type="text" id="price" name="price" placeholder='price...'required></br>
               </div>
            </div>
            <div class='row'>
               <div class='col-6'>
                  <label for id="quantity">Quantity</label>
                  <input class="form-control" type="text" id="quantity"name="quantity" placeholder='quantity...' required>
               </div>
            </div>  
            <div class="clearfix">
                <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
                <button type="submit" class="signupbtn" name="create">Add</button>
            </div>
      </article>
    </form>
</div>

<!--close the modal by just clicking outside of the modal-->
<script>
  var modal = document.getElementById('id01');

  window.onclick = function(event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
  }
</script>

</body>
</html>