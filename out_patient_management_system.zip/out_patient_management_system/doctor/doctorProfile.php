<html>
<head>
    <title>Profile|Doctor</title>
    <link rel="stylesheet" href="../css/admins.css">
    <link rel="stylesheet" href="../css/modal.css">
    <link rel="stylesheet" href="../Source/bootstrap-4.0.0-dist/css/bootstrap.min.css">
</head>
<body>
  <div class="container-fluid">
  <div class="row">
    <div class="col-lg-12">
      <div class="nav">
         <div class="logo">
           <h2><a class="navbar-brand" href="#">ONLINE OUT-PATIENT MANAGEMENT SYSTEM</a></h2>
         </div>
         <ul class="list">
         <li><a href="doctor.php">DOCTOR</a></li>
               <li><a href="managePatient.php">PATIENT DETAILS</a></li>
               <li><a href="doctorProfile.php" class='active'>PROFILE</a></li>
               <li><a href="#">Logout</a></li>
           </ul>
      </div>
     

      <div class="banner">
           <img src="../images/doctor6.png"/>
      </div>
      <button onclick="document.getElementById('id01').style.display='block'" style="width:100%;margin:auto;">Update Profile</button>
  </div>
  <!--------------------------------------------
        //  doctor profile
   ------------------------------------------------->
   <div class="col-12">
   <nav class="navbar ">
   </nav>
      </div> 
          <table class="table table-hover table-bordered">
                <tr class="bg-dark text-white  text-center">
                    <th>Doctor Name</th>
                    <th>Email</th>
                    <th>DOB</th>
                    <th>QUALIFICATION</th>
                    <th>EXPERIENCE</th>
                    <th>SPECIALTY</th>
                    <th>AVAILABILITY AT HOSPITAL</th>
                    <th>Update</th>
                </tr>
        <?php
               session_start();

               echo "Welcome Doctor" .$_SESSION['doctor_name']. "</br>";
              if(!isset($_SESSION['doctor_id']))
              {
                 header('location:../d_login.php');
              }
              // include 'connection.php';

              //connectivity
            $con=mysqli_connect("localhost","root") or die("not connected");
            //select database
            mysqli_select_db($con,"out_patient_management");


                $query="SELECT * FROM doctor where doctor_id='{$_SESSION['doctor_id']}'";
                $q=mysqli_query($con,$query);

                   while($res=mysqli_fetch_array($q))
                {


        ?>
                <tr class="text-center">
                    <td><?php echo $res['doctor_name']; ?></td>
                    <td><?php echo $res['email']; ?></td>
                    <td><?php echo $res['dob']; ?></td>
                    <td><?php echo $res['qualification']; ?></td>
                    <td><?php echo $res['year_of_experience']; ?></td>
                    <td><?php echo $res['specialty']; ?></td>
                    <td><?php echo $res['availability_at_hospital']; ?></td>
                    <td><button class="btn-primary btn"><a href="updationDoctor.php?id=<?php echo $res['doctor_id']; ?>" class="text-white">Update</a></button></td>
                </tr>

          <?php
        }
           ?>
          </table>
      </div>

  
    <!--------modal to update doctor---------->
   
  	<!--Step 1:Adding HTML-->
	<div id="id01" class="modal">
		<span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">×</span>
		<form class="modal-content animate" method='POST' action="addPatient.php">
			<div class="container">
			    <article class="card-body m-auto"> 
			        <div class='row'>
						<div class='col-6'>
							<label for id="name">Doctor Name</label>
		                    <input class="form-control" type="text" id="name"name="patient_name" placeholder='patient name...' required>
							<small></small>
						</div>
						<div class='col-6'>
						    <label for id="email">Email</label>
		                    <input class="form-control" type="text" id="email" name="email" placeholder='email...'required></br>
						</div>
                    </div>
                    <div class='row'>
						<div class='col-6'>
						    <label for id="dob">DOB</label>
                            <input class="form-control" type="date" id="dob" name="dob" placeholder='dob...'required></br>
						</div>
                        <div class='col-6'>
						    <label for id="qualification">QUALIFICATION</label>
                            <input class="form-control" type="text" id="qualification" name="qualification" placeholder='qualification...'required></br>
						</div>
                    </div>         
				    <div class='row'>
						<div class='col-6'>
						    <label for id="experience">EXPERIENCE</label>
		                    <select class="form-control" name="experience" required>
                                <option value="">Select</option>
                                <option value="1">1 Year</option>
                                <option value="2">2 Year</option>
                                <option value="3">3 Year</option>
                                <option value="4">4 Year</option>
                                <option value="5">5 Year</option>
                                <option value="more than 5 years">More Than 5 years</option>
                            </select></br>
					    </div>
						<div class='col-6'>
						    <label for id="address">Specialty</label>
                            <input class="form-control" type="text" name="specialty" placeholder='specialty...'required></br>
						</div>
                        <div class='col-6'>
						    <label for id="availability">Availability</label>
                            <select class="form-control" name="experience" required>
                                <option value="">Select</option>
                                <option value="yes">Yes</option>
                                <option value="no">No</option>
                            </select>                             
                        </div>
                    </div>	
                    	
                    <div class="clearfix">
					<button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
					<button type="submit" class="signupbtn" name="add">ADD</button>
				</div>
				</article>
			</div>
		</form>
	</div>

	<!--close the modal by just clicking outside of the modal-->
	<script>
		var modal = document.getElementById('id01');

		window.onclick = function(event) {
			if (event.target == modal) {
				modal.style.display = "none";
			}
		}
	</script>
    <!------------------->
</div>    
  <script src="JS/admin.js"></script>
</body>
</html>