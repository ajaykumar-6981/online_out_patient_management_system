<?php
  //connectivity
  $con=mysqli_connect("localhost","root") or die("not connected");
  //select database
  mysqli_select_db($con,"out_patient_management");

if(isset($_POST['create']))
{
 $fname=$_POST['fname'];
 $email=$_POST['email'];
 $password=$_POST['password'];
 $father_name=$_POST['father_name'];
 $dob=$_POST['dob'];
 $gender=$_POST['gender'];
 $address=$_POST['address'];
 $mobile_no=$_POST['mobile_no'];
 $prescription=$_FILES['prescription'];
 
print_r($prescription);
 
$sql="INSERT INTO appointments(fname,lname,email,password,father_name,dob,gender,address,mobile,prescription)
 VALUES('$fname','$lname','$email','$password','$father_name','$dob','$gender','$address','$mobile_no','$prescription')";

$qry=mysqli_query($con,$sql);

if($qry)
{
  ?>
         <script>                   // here script is out of php
                alert('Data Entered Successful');
        </script>

  <?php
}

}

echo $q="select * from patient INNERJOIN doctor ON patient.patient_id=doctor.doctor_id";
$res=mysqli_query($con,$q);
if($res){
	while($row=mysqli_fetch_assoc($res)){
		?>
<html>
  <head>
    <title>selectAppointment</title>
    <link rel='styleesheet' href='../css/registration.css'>
    <link rel="stylesheet" href="../Source/bootstrap-4.0.0-dist/css/bootstrap.min.css">
  </head>
  <body>
     <div class="container">
       <div class="card bg-light">
          <article class="card-body mx-auto" style="max-width:auto">
             <form class="c_registration.php" id='form' method="post">
        		<h2 class="card-title mt-3 text-center">Appointment</h2>
                    <div class="row">
					   <div class="col-lg-6">
                           <h2>Patient Details</h2>
						   <br>
						   <h3>Patient Name :<?php echo  $row['patient_name']?></h3>
						   <?php
						}
}
?>
					   </div>	
                    </div>	
	                <div class="row">
	                   <div class="col-lg-12">
	                        <h4>New Appointment</h4>
	                            <u>Fill up the forms with correct values</u>
		                          <hr class="mb-3">
                               
							   <div class='row'>
							        <div class='col-6'>
								        <label for id="patient">Patient</label>
		                                <select class="form-control" type="text" id="patient"name="patient">
											<?php 
											   $q="select * from patient";
											   $res=mysqli_query($con,$q);
											?>
											<option value="">Select</option>
											<option value="mohit">Mohit</option>
										</select>
							        </div>
								   <div class='col-6'>
								        <label for id="date">Date</label>
		                                <input class="form-control" type="date" id="date" name="date" placeholder='date...'required></br>
								   </div>
                               </div>
                               <div class='row'>
							        <div class='col-6'>
								       <label for id="dob">DOB</label>
		                               <input class="form-control"type="date" id="dob" name="dob" placeholder='dob...' required>
							        </div>
									<div class='col-6'>
								       <label for id="gender">Gender</label><br>
                                       Male:<input class="form-control" type="radio" name="gender" value="male">  Female:<input class="form-control" type="radio" name="gender" value="female">
								    </div>
							   </div>
							   <div class='row'>
							        <div class='col-6'>
								       <label for id="address">Address</label>
                                       <input class="form-control" type="text" id="address" name="address" placeholder='address...'required>
							        </div>
							    </div>
							    <div class='row'>
							       <div class='col-6'>
								      <label for id="mobile">Mobile No.</label>
		                              <input class="form-control" type="text" name="mobile_no" placeholder='mobile_no...'required/><br>
								   </div>
								   <div class='col-6'>
								      <label for id="prescription">Prescription</label>
		                              <input class="form-control" type="file" name="prescription" required/>
								   </div>
								</div>
															
		                     <button class="btn btn-primary btn-block" type="submit" name="create">Sign Up</button>

                        </div>
	                </div>
       </form>
     </article>
    </div>
   </div>
  
</body>

</html>
