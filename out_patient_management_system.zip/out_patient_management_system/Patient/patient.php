<?php
session_start();

if(!isset($_SESSION['fname']))
{
header('location:../p_login.php');
}

$con=mysqli_connect("localhost","root");
mysqli_select_db($con,"out_patient_management");

$query="SELECT * FROM doctor inner join doctor_schedule_table on doctor.doctor_id=doctor_schedule_table.doctor_id ";

if(isset($_POST['submit']))
{
 //$search_box=$_POST['search-box'];
 //  echo "submit is working";

 $searching=mysqli_real_escape_string($con,$_POST['search-box']);

  //$query .=" WHERE username LIKE '%".$searching."%'";

   $query .= " WHERE CONCAT(doctor_name)
               LIKE '%".$searching."%'";
}
$q=mysqli_query($con,$query);

$num=mysqli_num_rows($q);

?>

<html>
<head>
<title>Appointment |Patient</title>
    <link rel="stylesheet" href="../css/admins.css">
    <link rel="stylesheet" href="../Source/bootstrap-4.0.0-dist/css/bootstrap.min.css">
 
  <style type="text/css">
    .input-group
    {
      width:600px;
      margin: auto;
     }
    .h1{
      margin-top:5px;
      text:black;
      text-align:center;
      background-color:orange;
    } 
  </style>
</head>
<body>
    <div class="nav">
            <div class="logo">
              <h2><a class="navbar-brand" href="#">ONLINE OUT-PATIENT MANAGEMENT STORE</a></h2>
            </div>
            
            <ul class="list">
               <li><a class='active' href="patient.php">Deskboard</a></li>
               <li><a href="patientProfile.php">Profile</a></li>
               <li><a href="reset_pass.php">Change Password</a></li>
               <li><a href="../logout.php">Logout</a></li>
            </ul>
    </div>

<div class="container-fluid">
         <div class="banner">
               <img src="../images/doctor6.png"/>
           </div>
        </div>
    </br>

   <?php
      if(!$num)
      {
          echo '<p style="color: red; text-align: center">
          NO Such Medicine Available here.Sorry try next time...
          </p>';
     }
     ?>
  <br class="mb-3">
   <form method="post">
     <div class="input-group">
     <input type="text" name="search-box" class="form-control border-secondary text-black bg-transparent" placeholder="Search.........." placeholder="Enter Email" aria-describedby="button-addon2">
     <div class="input-group-append">
     <button class="btn btn-primary text-white" type="submit" name="submit">Search</button>
   <hr>

     </div>
   </div>
  </form>
  <h1 class="h1">Availability of Doctor</h1>
          <table class="table table-hover table-bordered">
                <tr class="bg-dark text-white  text-center">
                    <th>Doctor Name</th>
                    <th>Qualification</th>
                    <th>Specialty</th>
                    <th>Appointment Date</th>
                    <th>Appointment Day</th>
                    <th>Available Time</th>
                    <th>Consulting time</th>
                    <th>Action</th>
                </tr>
        <?php

              //connectivity
            $con=mysqli_connect("localhost","root");
            //select database
            mysqli_select_db($con,"out_patient_management");

              //  $q=mysqli_query($con,$query);

                   while($res=mysqli_fetch_array($q))
                {

        ?>
                <tr class="text-center">
                    <td><?php echo $res['doctor_name']; ?></td>
                    <td><?php echo $res['qualification']; ?></td>
                    <td><?php echo $res['specialty']; ?></td>
                    <td><?php echo $res['doctor_schedule_date']; ?></td>
                    <td><?php echo $res['doctor_schedule_day']; ?></td>
                    <td><?php echo $res['doctor_schedule_start_time']."-"; echo  $res['doctor_schedule_end_time']?></td>
                    <td><?php echo $res['average_consulting_time']; ?>min</td>
                    <td><button class="btn-warning btn"><a href="billing.php?id='<?php echo $_SESSION['patient_id']; ?>'">Book Appointment</a></button></td>
                </tr>
          <?php
        }
           ?>
          </table>
      </div>

  </div>
</div>