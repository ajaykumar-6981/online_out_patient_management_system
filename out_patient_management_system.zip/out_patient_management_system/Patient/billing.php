<?php

  session_start();

  $con=mysqli_connect('localhost','root');
  mysqli_select_db($con,'out_patient_management');

  if(isset($_POST['paybill'])){
     
      $p_id=$_GET["id"];
      
      echo $update_qry="UPDATE appointments SET status='Booked' WHERE patient_id='$p_id'";

        $res=mysqli_query($con,$update_qry);
  
        if($res){
            ?>
            <script> 
                 alert("Status of Appointment Updated");
            </script>
           <?php 
        }else{
            ?>
            <script>
                 alert("Status of Appointment not Updated");
            </script>
        <?php    
        }
      }
 
  
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Source/bootstrap-4.0.0-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/billing.css">
    <title>Payment</title>
   
</head>
<body>  
   <h1 class="heading">Billing</h1>
   <div class="containers">
    <div class="row">
        <div class="col-lg-6 col-md-6 mx-auto">
          <form method="POST" action="<?php echo $_SERVER['PHP_SELF']?>">  
            <label for="fname">Patient Name</label>
            <input class="form-control" type="text" id="fname" name="firstname" placeholder="full name..." value="<?php echo $_SESSION['fname']?>" readonly><br>
            <label for="email">Email</label>
            <input class="form-control" type="text" id="email" name="email" placeholder="email..." value="<?php echo $_SESSION['email']?>" readonly><br>
            <label for="adr">Address</label>
            <input class="form-control" type="text" id="adr" name="address" placeholder="address..." required><br>
            <label for="adr">Bill Amount</label>
            <input class="form-control" type="number" id="bill" name="bill" placeholder="Bill Amount..." required><br>
            <button name="paybill" class="btn-primary btn-block btn">PAY BILL</button>
            <button class="btn-warning btn-block btn"><a href="patient.php">Cancel</a></button>
           </form>  
          </div>
        </div>  
      </div>
    </div> 
</body>
</html>