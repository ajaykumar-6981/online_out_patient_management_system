<!DOCTYPE html>
<html>
<head>
<title>Untitled Document</title>
</head>
<body>

<?php
$con=mysqli_connect("localhost","root") or die("not connected");
//select database
mysqli_select_db($con,"out_patient_management");

if(isset($_POST['insert'])){
        $reason_for_appointment = $_POST['reason_for_appointment'];

        echo $insert = "Insert into appointments(reason_for_appointment) values ('$reason_for_appointment')" ;
        $result=mysqli_query($con,$insert);
        
        if($result) {
        echo ("Input data entered successfully");
        
        } else {
           ?> 
          <script>alert("Input data failed to be entered and proceed to billing");</script>
        <?php
        header('location:./patient/billing.php');
        }
       }
else {

echo $retrieve = "SELECT * FROM appointments inner join patient on appointments.patient_id=patient.patient_id";
if ($result=mysqli_query($con,$retrieve))
 {
  while ($res=mysqli_fetch_assoc($result))
  {
   ?>
    <div class="appointmentdiv">
    <table>
        <tr>
           <td>Patient Name<td><td><?php echo $res['fname']; ?></td>
        </tr>
        <hr>
        <tr>
          <td>Appointment time<td><td><?php echo $res['appointment_time']; ?></td>
        <tr>                 
          <td>Dob<td><td><?php echo $res['dob']; ?></td>
        </tr>
        <tr>
          <td>Father name<td><td><?php echo $res['father_name']; ?></td>
        </tr>
<tr>
</table>
<?php    

}
   
}}

?>

<h2>SELECT THE OPERATION YOU WANT TO PERFORM<h2>
<form method="post">
reason_for_appointment: <input type="text" name="reason_for_appointment" />

<input type="submit" name="insert" value="Insert" />

</form>
</div>
</body>
</html>