<?php
 
 $con=mysqli_connect("localhost","root");
 mysqli_select_db($con,"out_patient_management");

 if(isset($_SESSION['email'])){             //if session is set then we don't need to login again
     header('location:admin/admin.php');     
 }

//isset checks whether submit button is set or not
if(isset($_POST['submit']))
{
  $username=mysqli_real_escape_string($con,$_POST['email']);   //use function to make username more secure         
  $password=$_POST['password'];

  $sql="SELECT admin_id,email FROM admin WHERE email='{$username}' AND password='{$password}'";
 // echo $sql; 
 // die();
  $res=mysqli_query($con,$sql) or die("Query Failed");
  
  if(mysqli_num_rows($res) > 0)
  {
    while($row=mysqli_fetch_assoc($res)){
             session_start();
             $_SESSION["username"]=$row['name'];
             $_SESSION["admin_id"]=$row['admin_id'];
             $_SESSION["email"]=$row['email'];

             header('location:admin/admin.php');
       }
  }else{
      echo '<div class="alert alert-danger">User not matched!</div>';
  }

}

?>

<html>
<head>
  <title>admin login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="Source/bootstrap-4.0.0-dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/loginpage.css">
   
</head>
<body>
<section class="bgimage">
  <div class='info'>
   <h1 style='background-color:white;padding:2px 5px;'>LOGIN PAGE</h1> 
   <div class="imgbox">
   <img class="img" src="images/img_avatar2.png" style='text-align:center' width="200px" height="200px">
   </div>
   <a href="p_login.php" style='background-color:white;padding:1px 45px;'>Login for Patient</a><br>
   <a href="d_login.php" style='background-color:white;padding:1px 45px;'>Login for Doctor</a>
  </div>
    <div class="container">
      <div class="row">
         <div class="col-12 mx-auto">
           <div class="p-3 bg-grey">
            <h3>Login form for Admin</h3>

                <label>Login with your Account</label>
                
                <hr class="mb-3">
                <u>Fill up the forms</u>
            <form name="myForm" id="form" action="<?php $_SERVER['PHP_SELF']?>" onsubmit="return validateLogin()" method="post">
               
                <label for id="email">Email:</label>
                <input class="form-control" type="text" name="email" id="email"></br>

                <label for id="password">Password:</label>
                <input class="form-control" type="password" name="password" id="password" required></br>

                <button type="submit" name="submit" class="btn btn-primary btn-block">Login</button>
            
            </form>
        </div>
    </div>
   </div>
 </div>
 <script>
     function validateLogin()
     {
     const form=document.getElementById('form').value;
     const username=document.getElementById('admin_email').value;
     const password=document.getElementById('password').value;

     if(admin_email=''){
       alert("please enter your email");
       return false;
     }elseif(admin_email.length<4){
      alert("please enter min 5 characters");
       return false;
     }
     else{
        return true;
     }

     }
 </script>
</section>
</body>
</html>
