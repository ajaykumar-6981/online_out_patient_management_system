<?php

    //connectivity
  $con=mysqli_connect("localhost","root") or die("not connected");
  //select database
  mysqli_select_db($con,"out_patient_management");

if(isset($_POST['create']))
{
 $fname=$_POST['fname'];
 $lname=$_POST['lname'];
 $email=$_POST['email'];
 $password=$_POST['password'];
 $father_name=$_POST['father_name'];
 $dob=$_POST['dob'];
 $gender=$_POST['gender'];
 $address=$_POST['address'];
 $mobile_no=$_POST['mobile_no'];
 $register_date=$_POST['register_date'];
echo $sql="INSERT INTO patient(fname,lname,email,password,father_name,dob,gender,address,mobile,patient_add_on)
 VALUES('$fname','$lname','$email','$password','$father_name','$dob','$gender','$address','$mobile_no','$register_date')";

$qry=mysqli_query($con,$sql);

if($qry)
{
  ?>
         <script>                   // here script is out of php
                alert('Data Entered Successful');
        </script>

  <?php
}

}

?>


<html>
  <head>
    <title>Patient Registration</title>
    <link rel='styleesheet' href='css/registration.css'>
    <link rel="stylesheet" href="Source/bootstrap-4.0.0-dist/css/bootstrap.min.css">
  </head>
  <body>
     <div class="container">
       <div class="card bg-light">
          <article class="card-body mx-auto" style="max-width:auto">
             <form class="c_registration.php" id='form' method="post">
        		<h2 class="card-title mt-3 text-center">Create Account</h2>

	                <div class="row">
	                   <div class="col-lg-12">
	                        <h4>Registration form</h4>
	                            <u>Fill up the forms with correct values</u>
		                          <hr class="mb-3">
                               
							   <div class='row'>
							        <div class='col-6'>
								        <label for id="name">First Name</label>
		                                <input class="form-control" type="text" id="fname"name="fname" placeholder='firstname...'required>
							        </div>
								   <div class='col-6'>
								        <label for id="lname">Last Name</label>
		                                <input class="form-control" type="text" id="lname" name="lname" placeholder='lastname...'required></br>
								   </div>
                               </div>
                               <div class='row'>
							        <div class='col-6'>
								       <label for id="email">Email</label>
		                               <input class="form-control"type="text" id="email" name="email" placeholder='email...' required></br>
								    </div>
									<div class='col-6'>
								       <label for id="password">Password</label>
		                               <input class="form-control"type="password" id="password" name="password" placeholder='password..' required></br>
								   </div>
                               </div>
							   <div class='row'>
							      <div class='col-6'>
								       <label for id="father_name">Father's name</label>
		                               <input class="form-control"type="father_name" id="father_name" name="father_name" placeholder='father name..' required></br>
								   </div>
								   <div class='col-6'>
								       <label for id="dob">DOB</label>
		                               <input class="form-control"type="date" id="dob" name="dob" placeholder='dob...' required>
							        </div>
							   </div>
							   <div class='row'>
							        <div class='col-6'>
								       <label for id="gender">Gender</label><br>
                                       Male:<input class="form-control" type="radio" name="gender" value="male">  Female:<input class="form-control" type="radio" name="gender" value="female">
								    </div>
							        <div class='col-6'>
								       <label for id="address">Address</label>
                                       <input class="form-control" type="text" id="address" name="address" placeholder='address...'required>
							        </div>
							    </div>
							    <div class='row'>
							       <div class='col-6'>
								      <label for id="mobile">Mobile No.</label>
		                              <input class="form-control" type="text" name="mobile_no" placeholder='mobile_no...'required/><br>
								   </div>
								   <div class='col-6'>
								      <label for id="registerDate">Registration Date</label>
		                              <input class="form-control" type="date" name="register_date" placeholder='registeration Date...'required/><br>
								   </div>
								</div>
															
		                     <button class="btn btn-primary btn-block" type="submit" name="create">Sign Up</button>

                         <p>Have an Account?<a href="p_login.php">Sign in</a></p>
		               </div>
	                </div>

       </form>
     </article>
    </div>
   </div>
  
</body>

</html>
