const tooggle=document.getElementById("tooggle");
const side=document.querySelector(".side");
const closeBtn=document.querySelector(".close-btn");
const list=document.querySelector(".list");

tooggle.addEventListener("click",function(){
       
    //if(side.classList.contains("show-sidebar")){
    //    side.classList.remove("show-sidebar")      
   // }else{
   //     side.classList.add("show-sidebar");
   // }
   side.classList.toggle("show-sidebar");
});

closeBtn.addEventListener("click",function(){
    side.classList.remove("show-sidebar");s
});

