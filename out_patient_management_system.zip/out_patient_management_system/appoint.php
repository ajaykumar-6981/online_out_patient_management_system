
<?php
$con=mysqli_connect("localhost","root") or die("not connected");
//select database
mysqli_select_db($con,"out_patient_management");

if(isset($_POST['insert'])){
        $reason_for_appointment = $_POST['reason_for_appointment'];

        echo $insert = "Insert into appintments(reason_for_appointment) values ('$reason_for_appointment')" ;
        $result=mysqli_query($con,$insert);
        
        if($result) {
        echo ("Input data entered successfully");
        } else {
        echo ("Input data failed to be entered");
        }
       }
else {

echo $retrieve = "SELECT * FROM appointments inner join patient on appointments.patient_id=patient.patient_id";
if ($result=mysqli_query($con,$retrieve))
 {
  while ($res=mysqli_fetch_assoc($result))
{
    
    ?>
<table>
<tr>
<html>
<head>
    <title>Profile|Patient</title>
    <link rel="stylesheet" href="./css/admins.css">
    <link rel="stylesheet" href="./css/modal.css">
    <link rel="stylesheet" href="./Source/bootstrap-4.0.0-dist/css/bootstrap.min.css">
</head>
<body>
  <div class="container-fluid">
  <div class="row">
    <div class="col-lg-12">
      <div class="nav">
         <div class="logo">
           <h2><a class="navbar-brand" href="#">ONLINE OUT-PATIENT MANAGEMENT SYSTEM</a></h2>
         </div>
         <ul class="list">
               <li><a href="patient.php">PATIENT</a></li>
               <li><a href="doctorProfile.php" class='active'>PROFILE</a></li>
               <li><a href="#">Logout</a></li>
           </ul>
      </div>
     

      <div class="banner">
           <img src="./images/customer6.png"/>
      </div>
      
  </div>
  <!--------------------------------------------
        //  patient profile
   ------------------------------------------------->
  
    <!--------modal to update patient---------->
   
  	<!--Step 1:Adding HTML-->
	<div id="id01" class="modal">
	  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">×</span>
		   <div class="container">
			    <article class="card-body m-auto"> 
			        <div class='row'>
                <table class="table table-hover table-bordered">
                <tr>
                    <td>Patient Name<td><td><?php echo $res['fname']; ?></td>
                </tr>
                <tr>
                    <td>Email<td><td><?php echo $res['email']; ?></td>
                <tr>                 
                    <td>Dob<td><td><?php echo $res['dob']; ?></td>
                </tr>
                <tr>
                    <td>Father name<td><td><?php echo $res['father_name']; ?></td>
                </tr>
                <form class="modal-content animate" method='POST' action="updateProfile.php">
                  <div class='row'>
                    <div class="col">
                        <label>Reason for Appointment</label>
                        <input class="form-control" type="text" name="reason_for_appointment">
                        <input type="submit" name="insert" value="Insert" />
                    </div>
                  </div>  
          </form>  
                </div>

               </div> 
              <div class="clearfix">
					<button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
					<button type="submit" class="signupbtn" name="add">Update</button>
				</div>
        <?php
        }
      } 
           ?>
          </table>
          
				</article>
			</div>
		
	</div>

	<!--close the modal by just clicking outside of the modal-->
	<script>
		var modal = document.getElementById('id01');

		window.onclick = function(event) {
			if (event.target == modal) {
				modal.style.display = "none";
			}
		}
	</script>
    <!------------------->
</div>    
  <script src="JS/admin.js"></script>
</body>
</html>